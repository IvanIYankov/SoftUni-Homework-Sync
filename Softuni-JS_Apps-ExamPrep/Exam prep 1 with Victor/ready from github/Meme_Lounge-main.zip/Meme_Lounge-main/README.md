# Meme_Lounge

This is a web application for memes. The website allows the user to register with username, password and gender. Once you are registered you can create memes and you can see them in your profile and edit/delete them from there. If there is a missing field/s in the form the user gets notification as a pop-up on the right side of the screen.
The technologies used for this project are as follow:
* Dynamic HTML with lit-html
* Routing with page.js
* JavaScript
* The css used for this project was given from SoftUni